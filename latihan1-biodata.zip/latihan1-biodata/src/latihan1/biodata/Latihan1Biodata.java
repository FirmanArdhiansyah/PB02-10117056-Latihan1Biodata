/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package latihan1.biodata;

/**
 *
 * @author Firman Ardhiansyah IF-2 10117056
 */
public class Latihan1Biodata {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
    System.out.println("BIODATA ROCKSTAR"+"\n"+"----------------------------");
    System.out.println("NAMA\t\t: Firman Ardhiansyah");
    System.out.println("ALAMAT\t\t: Jalan Sekeloa No 25");
    System.out.println("TEMPAT LAHIR\t: 25 Januari 1999 ");
    System.out.println("------------------------------");
    System.out.println("HOBI\t\t: Futsal & Lari");
    System.out.println("MAKES\t\t: Ayam Goreng");
    System.out.println("MIKES\t\t: Es Campur");
    
    }
}
